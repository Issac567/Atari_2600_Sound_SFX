package main

import (
	"encoding/json"
	"errors"
)

func parseJson(jsonFile []byte) ([]Tone, error) {
	var tones []Tone
	err := json.Unmarshal(jsonFile, &tones)
	if err != nil {
		return nil, errors.New("failed to parse JSON tones: " + err.Error())
	}

	// Validate ranges
	for _, t := range tones {
		if t.Frequency < 1 || t.Frequency > 31 {
			return nil, errors.New("frequency out of range")
		}
		if t.Volume < 0 || t.Volume > 15 {
			return nil, errors.New("volume out of range")
		}
		if t.Control < 1 || t.Control > 15 {
			return nil, errors.New("control out of range")
		}
	}
	return tones, nil
}
